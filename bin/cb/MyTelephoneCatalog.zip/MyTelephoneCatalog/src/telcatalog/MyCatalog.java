/**
 * 
 */
package telcatalog;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author George.Pasparakis
 *
 */
public class MyCatalog {
	static String[] telCatalogNames = new String[50];
	static String[] telCatalogTels = new String[50];
	
	/**
	 * 
	 */
	public MyCatalog() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String fileName = new String();
		
		//  1. Read the file telcatalog.txt
		readFile("bin/telcatalog/telcatalog.txt");
		printEntries();
		
		//  2. The structure of the file is NAME,TEL
		//  3. Get from each line the NAME, TEL and store them to an array
		//  4. Create the method SearchArray(String name) that searches the array based on name
		//  5. Create the method SearchArray(String tel) that searches the array based on tel
		//  6. Create the method CreateEntry(String name, String tel) that inserts a new name,tel entry
		//  7. Create the method UpdateEntry(String name) that returns true if the method did the update 
		//  8. Create the method UpdateEntry(String tel) that returns true if the method did the update
		//  9. Create the method DeleteEntry(String name) that returns true if the method did the delete
		// 10. Create the method DeleteEntry(String tel) that returns true if the method did the delete
		
		// A. Do we need to create any new classes?
		// B. Do we have to create any new classes?
	}

	public static void readFile(String fileName) {
		try {

            File f = new File(fileName);

            BufferedReader b = new BufferedReader(new FileReader(f));

            String readLine = "";
            int index = 0;
            while ((readLine = b.readLine()) != null) {
                //System.out.println(readLine);
                telCatalogNames[index] = readLine.substring(0, readLine.indexOf(","));
                telCatalogTels[index] = readLine.substring(readLine.indexOf(",") + 1, readLine.length());
                index++;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	static void printEntries() {
		int i =0;
		
		for(i = 0; i < 50; i++) {
			System.out.println(telCatalogNames[i] + " - " + telCatalogTels[i]);
		}
	}
	
}
