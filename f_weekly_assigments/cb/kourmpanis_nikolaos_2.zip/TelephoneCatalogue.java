package f_weekly_assigments;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class TelephoneCatalogue {
	
	private int index;
	private String name;
	private String phone;

	public TelephoneCatalogue() {
		// TODO Auto-generated constructor stub
	}
	
	//Creates the 2D Array
	public static String[][] catalogueAll=new String[30][2];
	

	public static void CreateAllArray(String filename) {
		
		for(int r=0;r<catalogueAll.length;r++)	{
			for(int c=0;c<catalogueAll[0].length;c++) {
				catalogueAll[r][c]="-----";
				}
			}
		
		try {
			FileReader fr1=new FileReader(filename);
			BufferedReader br1=new BufferedReader(fr1);
			
			String newLine=null;
			
			int index=0;
			while((newLine=br1.readLine())!=null) {
				//System.out.println(newLine);
				catalogueAll[index][0]=newLine.substring(0,newLine.indexOf(","));
				catalogueAll[index][1]=newLine.substring((newLine.indexOf(",")+1),newLine.indexOf(",")+6);
				index++;
				}
			}
		catch(IOException e){
			}
		}
	
	
	//SETers & GETers for inputing NAME
	public void setName(String name) {
		this.name=name;
		}
	public String getName() {
		return name;
		}
	
	//SETers & GETers for inputing PHONE
	public void setPhone(String phone) {
		this.phone=phone;
		}
	public String getPhone() {
		return phone;
		}
	
	
	//Method used in the SEARCH BASED ON NAME 
	public String SearchArray2(String name) {
		setName(name);
		String str=null;
		for(int i=0;i<catalogueAll.length;i++) {
			try{
				if(catalogueAll[i][0].equals(getName())) {
					str="Phone found, "+getName()+" number's is: "+catalogueAll[i][1];
					break;
					}
				else {
					str="Phone not Found !!!";
					}
				}
			catch(Exception e) {
				}
			}
		return str;
		}
	
	
	//Method used in the SEARCH BASED ON PHONE
	public String SearchArray(String tel) {
		setPhone(tel);
		String str=null;
		for(int i=0;i<catalogueAll.length;i++) {
			try{
				if(catalogueAll[i][1].equals(getPhone())) {
					str="Name found "+getPhone()+" belongs to: "+catalogueAll[i][0];
					break;
					}
				else {
					str="Name not Found !!!";
					}
				}
			catch(Exception e) {	
				}
			}
		return str;
		}
	
	
	//Method used in ENTER NEW CONTACT
	public String CreateEntry(String name, String phone) {
		setName(name);
		setPhone(phone);
		boolean bool;
		String str=null;
		for(int i=0;i<catalogueAll.length;i++) {
			try{
				if(catalogueAll[i][0].equals("-----")) {
					bool=true;
					catalogueAll[i][0]=getName();
					catalogueAll[i][1]=getPhone();
					str=("New contact added succesfully("+bool+") "+
					"\n"+"[  "+getName()+"----->"+getPhone()+"  ] at index "+(i+1));
					break;
					}
				else {
					bool=false;
					str="Catalogue full("+bool+") Delete contacts to make room!!!";
					}
				}
			catch(Exception e) {
				}
			}
		return str;
		}

	
	
	
	//Method used in the UPDATE CONTACT BASED ON NAME(updates phone number)
	public String UpdateEntry(String name) {
		setName(name);
		boolean bool;
		String str=null;
		String newPhone=null;
		
		for(int i=0;i<catalogueAll.length;i++) {
			try{
				if(catalogueAll[i][0].equals(getName())) {
					bool=true;
					Scanner userIn2=new Scanner(System.in);
					System.out.print(getName()+" was found("+bool+") enter the new Phone number: ");
					newPhone=userIn2.next();
					setPhone(newPhone);
					catalogueAll[i][1]=getPhone();
					str="Update Done ("+bool+")"+"\n"+getName()+" new phone number is "+getPhone();
					break;
					}
				else {
					bool=false;
					str=getName()+" Not Found("+bool+")!!!";
					}
				}
			catch(Exception e) {
				}
			}
		
		return str;
		}
	
	
	//Method used in the UPDATE CONTACT BASED OF PHONE(updates owners Name)
	public String UpdateEntry2(String tel) {
		setPhone(tel);
		boolean bool;
		String str=null;
		String newName=null;
		
		for(int i=0;i<catalogueAll.length;i++) {
			try{
				if(catalogueAll[i][1].equals(getPhone())) {
					bool=true;
					Scanner userIn3=new Scanner(System.in);
					System.out.print(getPhone()+" was found("+bool+") enter the new Name: ");
					newName=userIn3.next();
					setName(newName);
					catalogueAll[i][0]=getName();
					str="Update Done ("+bool+")"+"\n"+getPhone()+"'s new owner is "+getName();
					break;
					}
				else {
					bool=false;
					str=getPhone()+" Not Found("+bool+")!!!";
					}
				}
			catch(Exception e) {				
			    }
			}
		return str;
		}
		
	
	//Method used in the DELETE CONTACT BASED ON NAME
	public String DeleteEntry(String name) {
		setName(name);
		boolean bool;
		String str=null;
		for(int i=0;i<catalogueAll.length;i++) {
			try{
				if(catalogueAll[i][0].equals(getName())) {
					bool=true;
					catalogueAll[i][0]="-----";catalogueAll[i][1]="-----";
					str=getName()+" was found("+bool+") and the contact was deleted";
					break;
					}
				else {
					bool=false;
					str=getName()+" Not Found("+bool+")!!!";
					}
				}
			catch(Exception e) {
				}
			}
		return str;
		}
	
	//Method used in the DELETE CONTACT BASED ON PHONE
	public String DeleteEntry2(String tel) {
		setPhone(tel);
		boolean bool;
		String str=null;
		for(int i=0;i<catalogueAll.length;i++) {
			try{
				if(catalogueAll[i][1].equals(getPhone())) {
					bool=true;
					catalogueAll[i][0]="-----";catalogueAll[i][1]="-----";
					str=getPhone()+" was found("+bool+") and the contact was deleted";
					break;
					}
				else {
					bool=false;
					str=getPhone()+" Not Found("+bool+")!!!";
					}
				}
			catch(Exception e) {
				}
			}
		return str;
		}
	
	
	//Method that shows the Array
	public static void ShowAllArray() {
		
		for(int r=0;r<catalogueAll.length;r++)	{
			System.out.print("[  ");
			for(int c=0;c<catalogueAll[0].length;c++) {
				System.out.print(catalogueAll[r][c]);
				for(int d=c;d<(catalogueAll[0].length)-1;d++) {
					try {
						for(int w=0;w<(16-(catalogueAll[r][c].length()));w++) {
							System.out.print("-");
							}
						}
					catch(Exception e) {
						}
					}
				}
			System.out.print("  ]");
			System.out.println();
			}
		}

	
}
	

